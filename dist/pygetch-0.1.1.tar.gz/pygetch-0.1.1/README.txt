=======
PyGetch
=======

PyGetch provides a simple set of utilities for using "getch" and "getch"-like
commands, all without echoing to the console.  It also provides some useful
STDOUT utilities for writing and re-writing to the console.

PyGetch is:

    * pure-Python

    * standard-library

    * platform-independent (-Nix and Windows)

